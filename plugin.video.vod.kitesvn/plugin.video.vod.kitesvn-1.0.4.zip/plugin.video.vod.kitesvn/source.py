# -*- coding: utf-8 -*-
import api
import urllib
import urlparse
import re


class Source:
	def __init__(self, cache_path):
		self.cache_path = cache_path
		self.base_url = 'http://www.kites.vn/'


	def __get_page__(self, url, cacheTime=3600000):
		return api.SOUPKit(cache_path=self.cache_path).SOUPFromURL(url, cacheTime=cacheTime)


	def base_url(self):
		return self.base_url


	def menu(self):
		page = self.__get_page__(self.base_url)

		menu = {}

		for cat in page.find_all('div', {'class': 'category-contents'}):
			header = cat.find('div', {'class': 'page-header'})
			if header <> None:
				header = header.find('h1').find('a').text.strip()
				cid = cat.find('div', {'id': re.compile('category-\\d+')})
				cid = re.findall('\\d+', cid['id'])
				if len(cid) > 0:
					menu[unicode(header)] = '%scategory?id=%s&page=1&in_limit=false' %(self.base_url, cid[0])

		return menu


	def contents(self, url):
		in_limit = False
		items = []
		while not in_limit:
			json = api.JSONKit(cache_path=self.cache_path).ObjectFromURL(url, headers={'X-Requested-With': 'XMLHttpRequest', 'Referer': 'http://www.kites.vn/'}, cacheTime=3600000)
			page = api.SOUPKit(cache_path=self.cache_path).SOUPFromString(json['data'])
			for li in page.find_all('li', {'id': re.compile('program_\\d+')}):
				href = self.base_url + li.find('a')['href']
				poster = li.find('a').find('img')['src']
				if poster.startswith('//'):
					poster = 'http:' + poster + '|User-Agent=iPad'
				elif poster.startswith('/'):
					poster = self.base_url + poster + '|User-Agent=iPad'
				title1 = li.find('div', {'class': 'program-info'}).find('h4').find('a').text
				items.append({'title1': unicode(title1), 'title2': unicode(title1), 'href': href, 'duration': '', 'info': '', 'poster': poster})

			if json['in_limit']:
				break
			p = urlparse.urlparse(url)
			q = urlparse.parse_qs(p.query)
			q['id'] = q['id'][0]
			q['in_limit'] = json['in_limit']
			q['page'] = int(q['page'][0]) + 1
			url = self.base_url + 'category?' + urllib.urlencode(q)
		return {'items': items, 'next_page': None}


	def media_items(self, url):
		media_items = {}

		page = self.__get_page__(url, 3600000)
		ep = page.find('li', {'id': re.compile('episode_\\d+')})['id']
		ep = re.findall('episode_(\\d+)', ep)

		title = page.find('h3', {'class': 'program-title'}).text
		title = title.split('/')

		if len(ep) > 0:
			cur = 1
			headers = {'Referer': self.base_url , 'X-Requested-With': 'XMLHttpRequest'}
			url = self.base_url + 'episode/playlist/%s' %ep[0]

			while True:
				data = {'id': ep[0], 'cur': cur, 'per': 10}
				json = api.JSONKit(cache_path=self.cache_path).ObjectFromURL(url, headers=headers, values=data, cacheTime=3600000)
				data = json['data']
				if data == False:
					break
				data = api.SOUPKit(cache_path=self.cache_path).SOUPFromString(data)

				for li in data.find_all('li', {'class': 'episode'}):
					a = li.find('h4').find('a')
					href = self.base_url + a['href']
					ep_title = a.find('span').text
					poster = li.find('img', {'class': 'img-responsive'})['src']
					if poster.startswith('//'):
						poster = 'http:' + poster + '|User-Agent=iPad'
					elif poster.startswith('/'):
						poster = self.base_url + poster + '|User-Agent=iPad'
					media_items[unicode(ep_title)] = [{'title1': unicode(title[2].strip()), 'title2': unicode(title[0].strip()), 'ep_title': ep_title, 'poster': poster, 'banner': poster, 'server_name': unicode('Server 1'), 'href': href}]
				cur = cur + 1
		return media_items


	def search(self, query):
		term = urllib.quote_plus(query)
		search_url = self.base_url + 'tim-kiem/%s/' %term
		return self.contents(search_url)


	def __next_page__(self, page):
		return None


	def resolve_stream(self, url):
		page = self.__get_page__(url)
		script = page.find('div', {'class': 'episode-player'}).find('script').text
		script = script.split(';')
		file_url = None
		path = None
		quality = None
		for s in script:
			m = re.search("(?i)var\\s+KitesVIDEO\\s+=.*'url':\\s+'(.*?)'", s.strip())
			if m:
				file_url = m.group(1).strip()
				continue
			m = re.search("(?i)KitesVIDEO\\['files'\\].*'(.*?)'", s.strip())
			if m:
				path = m.group(1)
				continue
			m = re.search("(?i)KitesVIDEO.quality\\['list'\\]\\s+=\\s+(.*)", s.strip())
			if m:
				quality = eval(m.group(1))
		if file_url <> None and path <> None:
			headers = {'Referer': self.base_url}
			return '%s/%s/%s|%s' %(file_url, quality[len(quality) - 1], path, urllib.urlencode(headers))
		return None


