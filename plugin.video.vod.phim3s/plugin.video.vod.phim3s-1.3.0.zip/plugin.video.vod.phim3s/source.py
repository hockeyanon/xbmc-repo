# -*- coding: utf-8 -*-

import re
import urlparse
import urllib
import json
import api


class Source:
	def __init__(self, cache_path):
		self.cache_path = cache_path
		self.base_url = 'http://phim3s.net/'


	def __get_page__(self, url, cacheTime=3600000):
		return api.SOUPKit(cache_path=self.cache_path).SOUPFromURL(url, cacheTime=cacheTime)


	def base_url(self):
		return self.base_url


	def menu(self):
		page = self.__get_page__(self.base_url)
		menu = {}
		content = page.find('div', {'id': 'menu'})
		for li in content.find_all('li', {'class': 'item'}):
			a = li.find('a')
			if type(a) is int and a < 0: continue
			if 'javascript' in a['href']:
				submenu = []
				sub_ul = li.find('ul', {'class': 'sub'})
				for s in sub_ul.find_all('a'):
					submenu.append({'label': s.text.strip(), 'href': self.base_url + s['href'] + "?order_by=last_update"})
				menu[unicode(a.text)] = submenu
			else:
				menu[unicode(a.text)] = self.base_url + a['href'] + "?order_by=last_update"

		return menu


	def contents(self, url):
		page = self.__get_page__(url)
		contents = []
		temp = []
		for c in page.find_all('div', {'class': 'inner'}):
			a = c.find('a', {'class': 'poster'})
			href = self.base_url + a['href'] + '/xem-phim/'
			if href in temp or href.startswith('clip'):
				continue
			temp.append(href)
			poster = a.find('img')['src']
			status = c.find('span', {'class': 'status'})
			if status <> None:
				status = status.text
			if status == 'Trailer':
				continue
			title = c.find('a', {'class': 'name'})['title']
			title = title.split('-')
			title1 = None
			title2 = None
			if len(title) == 1:
				title1 = title[0].strip()
			else:
				title1 = title[0].strip()
				title2 = title[1].strip()
			contents.append({'title1': unicode(title1), 'title2': unicode(title2), 'href': href, 'duration': unicode(status), 'info': status, 'poster': poster})

		next_page = self.__next_page__(page)
		return {'items': contents, 'next_page': next_page}


	def media_items(self, url):
		page = self.__get_page__(url)

		poster = page.find('meta', {'property': 'og:image'})['content']
		title1 = page.find('h2', {'class': 'item'}).find('span', {'itemprop': 'title'}).text
		re_name = re.compile("(?i)name.*")
		re_eps = re.compile("(?i)episode.*")

		media_items = {}
		serverList = page.find('div', {'class': 'block servers'})
		if serverList <> None:
			for server in serverList.find_all('div', {'class': 'server'}):
				serverName = server.find('div', {'class': re_name}).text.strip()
				streams = []
				for e in server.find('div', {'class': re_eps}).find_all('a'):
					href = '%s%s' %(self.base_url, e['href'])
					s = []
					ep_title = u''.join([u'Tập ', e.text])
					if ep_title in media_items:
						s = media_items[unicode(ep_title)]
					s.append({'title1': unicode(title1), 'title2': '', 'ep_title': ep_title, 'poster': poster, 'banner': '', 'server_name': unicode(serverName), 'href': href})
					media_items[unicode(ep_title)] = s

		if media_items == {}:
			media_items['DEFAULT'] = [{'title1': unicode(title1), 'title2': '', 'ep_title': '', 'poster': poster, 'banner': '', 'server_name': unicode('Server 1'), 'href': url}]
		return media_items


	def search(self, query):
		search_url = self.base_url + 'search?' + urllib.urlencode({'keyword': urllib.quote_plus(query)})
		return self.contents(search_url)


	def __next_page__(self, page):
		pages = page.find('span', {'class': 'page_nav'})
		if pages is None:
			return None
		n = pages.find('span', {'class': 'current'})
		if n is None:
			return None

		next_sib = n.nextSibling
		if next_sib <> None:
			n = next_sib.find('a')['href']
			return self.base_url + n
		return None


	def resolve_stream(self, url):
		page = self.__get_page__(url)
		flash = page.find('param', {'name': 'flashVars'})
		value = flash['value']
		value = urlparse.parse_qs(value)
		link = value['proxy.link'][0]

		result = api.HTTPKit(self.cache_path).Reqest('http://sub1.phim3s.net/v3/plugins_player.php?isslverify=true&url=' + link).content
		rates = json.loads(result)
		max_rate = 0
		loc = None
		for c in rates['content']:
			if c['type'] == 'video/mpeg4':
				h = int(c['height'])
				if h > max_rate:
					max_rate = h
					loc = c['url']
		return loc


	def normalize_str(self, string):
		s = re.sub(r'\s+', ' ', string)
		return s.strip()

