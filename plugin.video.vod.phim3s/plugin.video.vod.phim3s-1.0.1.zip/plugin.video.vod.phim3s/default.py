# -*- coding: utf-8 -*-

import urllib
import sys
import HTTP
import xbmc,xbmcplugin,xbmcgui,xbmcaddon
import source

try:
	import StorageServer
except:
	import storageserverdummy as StorageServer


# GLOBAL VARS
PLUGIN_ID = 'plugin.video.vod.phim3s'
PLUGIN = int(sys.argv[1])

# CACHING
cache = StorageServer.StorageServer(PLUGIN_ID, 3)
cache.table_name = PLUGIN_ID

# SETTINGS
settings = xbmcaddon.Addon(id=PLUGIN_ID)
xbmcplugin.setContent(PLUGIN, 'movies')


class main:
	def __init__(self):

		params = {}
		splitparams = sys.argv[2][sys.argv[2].find('?') + 1:].split('&')
		for param in splitparams:
			if (len(param) > 0):
				splitparam = param.split('=')
				key = splitparam[0]
				try:    value = splitparam[1].encode("utf-8")
				except: value = splitparam[1]
				params[key] = value

		action = None
		try:        action = urllib.unquote_plus(params["action"])
		except:     action = None
		try:        key = urllib.unquote_plus(params["key"])
		except:     key = None
		try:        path = urllib.unquote_plus(params["path"])
		except:     path = ""
		try:        meta_key = urllib.unquote_plus(params["meta_key"])
		except:     meta_key = ""
		try:        stream_key = urllib.unquote_plus(params["stream_key"])
		except:     stream_key = ""
		try:        page = urllib.unquote_plus(params["page"])
		except:     page = 1

		if action == None:                            self.main_menu()
		elif action == 'sub_menu':                    self.sub_menu(key)
		elif action == 'list_medias':                 self.list_medias(path, int(page))
		elif action == 'list_media_items':            self.list_media_items(path)
		elif action == 'play':                        self.play(meta_key, stream_key)
		elif action == 'search':					  self.search()


	def build_url(self, query):
		return sys.argv[0] + '?' + urllib.urlencode(query)


	def main_menu(self):
		menu = cache.get('main_menu')
		if menu is None or menu == '':
			s = source.source()
			menu = s.menu()
			cache.set('main_menu', repr(menu))
		else:
			menu = eval(menu)

		for mi in menu:
			obj = menu[mi]
			if type(obj) is list:
				u = self.build_url({'action': 'sub_menu', 'key': mi.encode('utf-8')})
			else:
				u = self.build_url({'action': 'list_medias', 'path': obj})

			item = xbmcgui.ListItem(mi)
			xbmcplugin.addDirectoryItem(handle=PLUGIN, url=u, listitem=item, isFolder=True)

		#search
		xbmcplugin.addDirectoryItem(handle=PLUGIN, url=self.build_url({'action': 'search'}), listitem=xbmcgui.ListItem(u'Tìm Kiếm'), isFolder=True)
		xbmcplugin.endOfDirectory(PLUGIN)


	def sub_menu(self, key):
		menu = cache.get('main_menu')
		if menu is None or menu == '':
			s = source.source()
			menu = s.menu()
			cache.set('main_menu', repr(menu))
		else:
			menu = eval(menu)

		_key = key.decode('utf-8')
		for mi in menu[_key]:
			u = self.build_url({'action': 'list_medias', 'path': mi['href']})
			item = xbmcgui.ListItem(mi['label'])
			xbmcplugin.addDirectoryItem(handle=PLUGIN, url=u, listitem=item, isFolder=True)

		xbmcplugin.endOfDirectory(PLUGIN)


	def list_medias(self, path, page = 1):
		contents = cache.get(path)
		if contents is None or contents == '':
			s = source.source()
			contents = s.contents(path)
			cache.set(path, repr(contents))
		else:
			contents = eval(contents)

		self.__list_medias__(contents, page)


	def list_media_items(self, path):
		contents = cache.get(path)

		if contents is None or contents == '' or contents == {}:
			s = source.source()
			contents = s.media_items(path)
			cache.set(path, repr(contents))
		else:
			contents = eval(contents)

		### if 1 content
		if len(contents) == 1:
			self.play(path, list(contents.keys())[0].encode('utf-8'))

		### list all episodes/parts
		elif len(contents) > 1:
			for key in sorted(contents):
				c = contents[key][0]
				u = self.build_url({'action': 'play', 'meta_key': path, 'stream_key': key.encode('utf-8')})
				item = xbmcgui.ListItem(key)
				item.setArt({'poster': c['poster'], 'thumb': c['poster'], 'fanart': c['banner'], 'landscape': c['banner']})
				xbmcplugin.addDirectoryItem(handle=PLUGIN, url=u, listitem=item, isFolder=False)
			xbmcplugin.endOfDirectory(PLUGIN)


	def search(self):
		kb = xbmc.Keyboard('', u'Tìm Kiếm')
		kb.doModal()

		result = None
		if kb.isConfirmed():
			result = kb.getText()

		if result <> None:
			s = source.source()
			contents = s.search(result)
			self.__list_medias__(contents)


	def __list_medias__(self, contents, page=1):
		for c in contents['items']:
			u = self.build_url({'action': 'list_media_items', 'path': c['href']})
			item = xbmcgui.ListItem(c['title1'])
			item.setInfo(type="Video", infoLabels={'title': c['title1'], 'originaltitle': c['title2'], 'plot': c['info']})
			item.setArt({'poster': c['poster'], 'thumb': c['poster']})
			xbmcplugin.addDirectoryItem(handle=PLUGIN, url=u, listitem=item, isFolder=True)

		next_page = contents['next_page']
		if next_page <> None and next_page <> '':
			item = xbmcgui.ListItem(u'Xem thêm')
			u = self.build_url({'action': 'list_medias', 'path': next_page, 'page': page + 1})
			xbmcplugin.addDirectoryItem(handle=PLUGIN, url=u, listitem=item, isFolder=True)
		xbmcplugin.endOfDirectory(PLUGIN)


	def play(self, meta_key, stream_key):
		s = source.source()
		#get metadata based on the key
		contents = cache.get(meta_key)
		if contents is None or contents == '' or contents == {}:
			contents = s.media_items(meta_key)
			cache.set(meta_key, repr(contents))
		else:
			contents = eval(contents)

		#this is a list of servers
		c = contents[stream_key.decode('utf-8')]
		if len(c) == 1:
			c = c[0]
		else:
			dlg = xbmcgui.Dialog()
			opts = []
			for i in c:
				opts.append(i['server_name'])

			ret = dlg.select('Chọn Server', opts)
			if ret > -1:
				c = c[ret]
			else:
				c = None
			del dlg

		if c <> None:
			progress = xbmcgui.DialogProgress()
			progress.create(u'Đăng Tải Phim')
			try:
				stream_url = s.resolve_stream(c['href'])
			finally:
				progress.close()
				del progress

			if stream_url <> None:
				label = c['title1']
				if c['ep_title'] <> '':
					label = u''.join([label, ' - ', c['ep_title']])
				item = xbmcgui.ListItem(label)
				item.setArt({'poster': c['poster'], 'thumb': c['poster'], 'fanart': c['banner'], 'landscape': c['banner']})
				xbmc.Player().play(stream_url, item)
			else:
				xbmcgui.Dialog().notification('Error', u'Link phim có thể bị hỏng, thử chọn server khác.')


main()
