# -*- coding: utf-8 -*-
import api
import urllib
from bs4 import element


class Source:
	def __init__(self, cache_path):
		self.cache_path = cache_path
		self.base_url = 'http://www.phimlt.com/'


	def __get_page__(self, url, cacheTime=3600000):
		return api.SOUPKit(cache_path=self.cache_path).SOUPFromURL(url, cacheTime=cacheTime)


	def base_url(self):
		return self.base_url


	def menu(self):
		page = self.__get_page__(self.base_url)
		menu = {}
		content = page.find('ul', {'class': 'container menu'})
		for li in content.children:
			if type(li) == element.Tag:
				a = li.find('a')
				label = a.text
				if label == '':
					continue
				if 'href' in a.attrs:
					href = a['href']
					if 'actor' not in href:
						menu[unicode(label)] = href
				#sub menu
				sub_ul = li.find('ul', {'class': 'sub-menu'})
				sub_menu = []
				if sub_ul <> None:
					if sub_ul['id'] == 'sub-phimbo':
						label = u'Quốc Gia'
					for sa in sub_ul.find_all('a'):
						rel_link = sa['href']
						if rel_link == './':
							rel_link = ''
						sub_menu.append({'href': rel_link, 'label': unicode(sa.text)})
					if len(sub_menu) > 0:
						menu[unicode(label)] = sub_menu

		return menu


	def contents(self, url):
		page = self.__get_page__(url)
		items = []
		duplicates = []
		div = page.find_all('div', {'class': 'inner'})
		for i in div:
			poster = i.find('img', {'class': 'thumb'})['src']
			t = i.find('div', {'class': 'title'})
			a = t.find('a')
			href = a['href']
			title1 = a.text
			duration = i.find('div', {'class': 'status'}).text

			if not href in duplicates:
				duplicates.append(href)
				items.append({'title1': unicode(title1), 'title2': '', 'href': href, 'duration': unicode(duration), 'info': '', 'poster': poster})


		next_page = self.__next_page__(page)
		return {'items': items, 'next_page': next_page}


	def media_items(self, url):
		page = self.__get_page__(url)
		poster = None
		banner = None

		info = page.find('div', {'class': 'phim_img'})
		poster = info.find('img')['src']
		title = info.find('a')['title'].split('-')
		title1 = title[0].strip()
		title2 = ''
		media_items = {}


		for s in page.find_all('div', {'class': 'listserver'}):
			name = s.find('span', {'class': 'servername'})
			if name is None:
				continue
			name = name.text.strip()
			name = name.replace('\r', '').replace('\n', '')

			episodes = s.find('ul', {'class': 'episodelist-info-page'})
			for e in episodes.find_all('a'):
				ep_title = e.text.strip()
				ep_title = ep_title.replace('\r', '').replace('\n', '')
				ep_title = u''.join([u'Tập ', ep_title])
				href = e['href']
				s = []
				if ep_title in media_items:
					s = media_items[unicode(ep_title)]
				s.append({'title1': unicode(title1), 'title2': unicode(title2), 'ep_title': ep_title, 'poster': poster, 'banner': banner, 'server_name': unicode(name), 'href': href})
				media_items[unicode(ep_title)] = s

		if media_items == {}:
			media_items['DEFAULT'] = [{'title1': unicode(title1), 'title2': unicode(title2), 'ep_title': '', 'poster': poster, 'banner': banner, 'server_name': unicode('Server 1'), 'href': url}]

		return media_items


	def search(self, query):
		search_url = self.base_url + 'search/%s' %(urllib.quote(query))
		return self.contents(search_url)


	def __next_page__(self, page):
		pages = page.find('ul', {'class': 'pages'})
		if pages is None:
			return None

		pages = pages.find_all('a')
		if page is None or len(pages) == 0:
			return None

		for i, p in enumerate(pages):
			if 'class' in p.attrs:
				if i+1 < len(pages):
					return pages[i+1]['href']

		return None


	def resolve_stream(self, url):
		page = self.__get_page__(url)
		video = page.find('video', {'id': 'mediaplayer'})

		if 'HD' in video.attrs:
			return video['HD']
		if 'nonHD' in video.attrs:
			return video['nonHD']
		return video.find('source')['src']


