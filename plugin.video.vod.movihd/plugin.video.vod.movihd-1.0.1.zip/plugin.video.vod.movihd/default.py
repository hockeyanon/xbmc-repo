# -*- coding: utf-8 -*-

import urlparse
import urllib,urllib2
import cookielib
import xbmc,xbmcplugin,xbmcgui,xbmcaddon

import sys
import re
import json
from bs4 import BeautifulSoup

import HTTP

try:
	import StorageServer
except:
	import storageserverdummy as StorageServer


# GLOBAL VARS
PLUGIN_ID = 'plugin.video.vod.movihd'
BASE_URL = 'http://movihd.net'
USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; rv:34.0) Gecko/20100101 Firefox/34.0'

# CACHING
cache = StorageServer.StorageServer(PLUGIN_ID, 3)
cache.table_name = PLUGIN_ID

# SETTINGS
settings = xbmcaddon.Addon(id=PLUGIN_ID)

xbmcplugin.setContent(int(sys.argv[1]), 'movies')


action              = None


class main:
	def __init__(self):
		global action
		params = {}
		splitparams = sys.argv[2][sys.argv[2].find('?') + 1:].split('&')
		for param in splitparams:
			if (len(param) > 0):
				splitparam = param.split('=')
				key = splitparam[0]
				try:    value = splitparam[1].encode("utf-8")
				except: value = splitparam[1]
				params[key] = value

		try:        action = urllib.unquote_plus(params["action"])
		except:     action = None
		try:        key = urllib.unquote_plus(params["key"])
		except:     key = None
		try:        path = urllib.unquote_plus(params["path"])
		except:     path = ""
		try:        page = urllib.unquote_plus(params["page"])
		except:     page = 1

		if action == None:                            self.MainMenu()
		elif action == 'SubMenu':                     self.SubMenu(key)
		elif action == 'ListContents':                self.ListContents(path, int(page))
		elif action == 'ListMedias':                  self.ListMedias(path)
		elif action == 'Play':                        self.Play(path)
		elif action == 'Search':					  self.Search()


	def BuildUrl(self, query):
		return sys.argv[0] + '?' + urllib.urlencode(query)


	def MainMenu(self):
		menu = cache.get('main_menu')
		if menu is None or menu == '':
			doc = HTTP.Retrieve(BASE_URL, mobile=True)
			doc = BeautifulSoup(doc)
			menu = self.BuildMenu(doc)
			cache.set('main_menu', repr(menu))
		else:
			menu = eval(menu)

		for mi in menu:
			obj = menu[mi]
			if type(obj) is list:
				u = self.BuildUrl({'action': 'SubMenu', 'key': mi.encode('utf-8')})
			else:
				u = self.BuildUrl({'action': 'ListContents', 'path': obj})

			item = xbmcgui.ListItem(mi)
			xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=item, isFolder=True)

		#search
		item = xbmcgui.ListItem(u'Tìm Kiếm')
		xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=self.BuildUrl({'action': 'Search'}), listitem=item, isFolder=True)

		xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=True)


	def SubMenu(self, key):
		xbmcplugin.setContent(int(sys.argv[1]), 'videos')

		menu = cache.get('main_menu')
		if menu is None or menu == '':
			doc = HTTP.Retrieve(BASE_URL, mobile=True)
			doc = BeautifulSoup(doc)
			menu = self.BuildMenu(doc)
			cache.set('main_menu', repr(menu))
		else:
			menu = eval(menu)

		_key = key.decode('utf-8')
		for mi in menu[_key]:
			u = self.BuildUrl({'action': 'ListContents', 'path': mi['href']})
			item = xbmcgui.ListItem(mi['label'])
			xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=item, isFolder=True)

		xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=True)


	def ListContents(self, path, page = 1):
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		contents = cache.get(path)

		if contents is None or contents == '':
			doc = HTTP.Retrieve(path, mobile=True)
			doc = BeautifulSoup(doc)
			next_page = self.NextPage(doc, page)
			contents = self.Contents(doc)
			cache.set(path + "|next_page", next_page)
			cache.set(path, repr(contents))
		else:
			contents = eval(contents)
			next_page = cache.get(path + "|next_page")

		for c in contents:
			href = c['href']
			poster = c['poster']
			vn_title = c['vn_title']
			en_title = c['en_title']

			u = self.BuildUrl({'action': 'ListMedias', 'path': href})
			item = xbmcgui.ListItem(vn_title)
			#needed?
			item.setLabel(vn_title)
			item.setLabel2(en_title)

			item.setInfo(type="Video", infoLabels={'title': vn_title, 'originaltitle': en_title})
			item.setArt({'poster': poster, 'thumb': poster, 'landscape': poster})
			xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=item, isFolder=True)


		if next_page <> None and next_page <> '':
			item = xbmcgui.ListItem(u'Xem thêm')
			u = self.BuildUrl({'action': 'ListContents', 'path': next_page, 'page': page + 1})
			xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=item, isFolder=True)

		xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)


	def ListMedias(self, path):
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
		contents = cache.get(path)

		if contents is None or contents == '':
			doc = HTTP.Retrieve(path, mobile=True)
			doc = BeautifulSoup(doc)
			contents = self.MediaItems(doc)
			cache.set(path, repr(contents))
		else:
			contents = eval(contents)

		if len(contents) > 1:
			for c in contents:
				banner = c['banner']
				poster = c['poster']
				title = c['title']
				episode_title = c['episode_title']
				description = c['description']
				href = c['href']

				cache.set(href + '|item', repr(c))

				item = xbmcgui.ListItem(episode_title)

				item.setInfo(type="Video", infoLabels={'title': title, 'originaltitle': title, 'plot': title})
				item.setArt({'poster': poster, 'thumb': poster, 'landscape': poster, 'banner': banner, 'fanart': banner})
				item.setProperty("Fanart_Image", banner)
				u = self.BuildUrl({'action': 'Play', 'path': href})
				xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=item, isFolder=False)

			xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)
		else:
			c = contents[0]
			cache.set(c['href'] + '|item', repr(c))
			self.Play(c['href'])


	def Play(self, path):
		bitrates = cache.get(path)
		if bitrates is None or bitrates == '':
			progress = xbmcgui.DialogProgress()
			progress.create(u'Đăng Tải Phim')
			try:
				doc = HTTP.Retrieve(path, mobile=True)
				bitrates = json.loads(doc)
				cache.set(path, repr(bitrates))
			finally:
				progress.close()
				del progress
		else:
			bitrates = eval(bitrates)

		bt = None

		#find one
		cq = settings.getSetting('playback_quality')
		for bitrate in bitrates['bitrates']:
			b = bitrate['bitrate']
			q = b['bitrate_label']
			if q == cq:
				bt = b
				break

		# couldn't find any stream based on config, use first one
		if bt is None and len(bitrates['bitrates']) > 0:
			bt = bitrates['bitrates'][0]['bitrate']

		url_path = bt['url_path']

		item_str = cache.get(path + '|item')
		c = eval(item_str)

		banner = c['banner']
		poster = c['poster']
		title = c['title']
		episode_title = c['episode_title']
		description = c['description']
		href = c['href']

		item = xbmcgui.ListItem(episode_title)

		item.setInfo(type="Video", infoLabels={'title': episode_title, 'originaltitle': title})
		item.setArt({'poster': poster, 'thumb': poster, 'landscape': poster, 'banner': banner, 'fanart': banner})
		xbmc.Player().play(url_path, item)


	def Search(self):
		kb = xbmc.Keyboard('', u'Tìm Kiếm')
		kb.doModal()

		result = None
		if kb.isConfirmed():
			result = kb.getText()

		if result <> None:
			search_url = '%s/instant-search' %(BASE_URL)
			search = "{'txt': '%s'}" % result
			result = HTTP.Retrieve(url = search_url, post=search, headers={'Content-Type': 'application/json; charset=utf-8', 'Accept': 'application/json, text/javascript, */*; q=0.01'})
			print result


	def BuildMenu(self, page):
		menu = {}
		nav = page.find('nav', {'class': 'tn-gnav'}).find('ul')
		for li in nav.children:
			a = li.find('a')
			if a is None or (type(a) is int and int(a) < 0): continue
			if 'javascript' in a['href']: continue

			menu_name = a.text.strip()
			menu_href = BASE_URL + a['href']
			sub_menu = li.find('div', {'class': 'tn-gnavsub'})

			menu[menu_name] = menu_href
			if sub_menu <> None:
				tmp_name = menu_name
				if menu_name == u'PHIM LẺ':
					tmp_name = u'NĂM'
				items = []
				for a in sub_menu.findAll('a'):
					items.append({'label': unicode(a.text), 'href': BASE_URL + a['href']})
				menu[tmp_name] = items

		return menu


	def Contents(self, page):
		contents = []
		for i in page.find_all('div', {'class': 'block-base movie'}):
			film_title = i.find('a', {'class': 'film-name'})
			if film_title is None: continue
			#title
			href = film_title['href']
			vn_title = unicode(film_title.find('h2').text).strip()
			en_title = unicode(film_title.find('h2').next_sibling).strip()
			#img
			poster = BASE_URL + i.find('img', {'class': 'thumb lazy'})['src']
			contents.append({'href': BASE_URL + href, 'vn_title': vn_title, 'en_title': en_title, 'poster': poster})
		return contents


	def MediaItems(self, page):
		link = re.compile(".*\('(.*)'\)")
		div = page.find('div', {'id': 'ctl00_ContentBanner_PlayerForm'})
		banner = BASE_URL + div.find('img', {'class': 'playerbg'})['src']
		thumb = BASE_URL + div.find('img', {'class': 'thumb'})['src']
		items = page.find('div', {'class': 'section-title step'})

		title = div.find('span', {'id': 'ctl00_ContentBanner_txtFilmName'}).text.strip()
		description = div.find('span', {'id': 'ctl00_ContentBanner_txtFilmToolTip'}).text.strip()
		media_items = []

		if items <> None:
			for a in items.find_all('a'):
				text = u''.join([u'Tập', ' ', a.text])
				href = a['href']
				match = link.match(href)
				if match:
					href = 'http://movihd.net/playlist/%s.xml' %match.group(1)
					media_items.append({'banner': banner, 'poster': thumb, 'episode_title': unicode(text), 'title': unicode(title), 'description': description, 'href': href})
		else:
			href = page.find('a', {'class': 'playerbuttoninfo'})['href']
			match = link.match(href)
			if match:
				href = 'http://movihd.net/playlist/%s.xml' %match.group(1)
				media_items.append({'banner': banner, 'poster': thumb, 'episode_title': unicode(title), 'title': unicode(title), 'description': description, 'href': href})
		return media_items


	def NextPage(self, page, page_index = 1):
		pages = page.find('div', {'class': 'section-title pagination'})
		if pages is None:
			return None

		for a in pages.find_all('a'):
			i = int(a.text)
			if page_index + 1 == i:
				return BASE_URL + a['href']
		return None

main()
