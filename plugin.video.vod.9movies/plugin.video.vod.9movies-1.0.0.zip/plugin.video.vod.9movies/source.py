# -*- coding: utf-8 -*-

import re
import urlparse
import urllib
import json
import api


class Source:
	def __init__(self, cache_path):
		self.cache_path = cache_path
		self.base_url = 'http://9movies.to/'


	def __get_page__(self, url, cacheTime=3600000):
		return api.SOUPKit(cache_path=self.cache_path).SOUPFromURL(url, cacheTime=cacheTime)


	def base_url(self):
		return self.base_url


	def menu(self):
		page = self.__get_page__(self.base_url)
		menu = {}
		content = page.find('ul', {'id': 'menu'})
		for li in content.children:
			a = li.find('a')
			if type(a) is int: continue
			submenu = []
			sub_ul = li.find('ul', {'class': 'sub-menu'})
			if sub_ul <> None:
				for s in sub_ul.find_all('a'):
					submenu.append({'label': s.text.strip(), 'href': self.base_url + s['href']})
				menu[unicode(a.text)] = submenu
			elif 'href' in a.attrs:
				l = unicode(a.text.strip())
				if l == u'Home':
					menu[u'Latest'] = a['href']
				else:
					menu[l] = self.base_url + a['href']

		return menu


	def contents(self, url):
		page = self.__get_page__(url)
		contents = []
		dups = []
		for ul in page.find_all('ul', {'class': 'movie-list'}):
			for li in ul.children:
				a = li.find('a')
				if type(a) is int: continue
				href = self.base_url + a['href']
				if href not in dups:
					dups.append(href)
					title1 = a['title']
					poster = a.find('img')['src']
					duration = li.find('div', {'class': 'duration'}).text
					info = li.find('div', {'class': 'details-tip'}).find('p').text
					info = re.sub('\W+', ' ', info)

					contents.append({'title1': unicode(title1), 'title2': '', 'href': href, 'duration': unicode(duration), 'info': info, 'poster': poster})

		next_page = self.__next_page__(page)
		return {'items': contents, 'next_page': next_page}


	def media_items(self, url):
		page = self.__get_page__(url, cacheTime=1000*60*5)
		media_items = {}

		fanart = page.find('a', {'class': 'cover'})
		if 'style' in fanart.attrs:
			fanart = fanart['style']
			fanart = fanart[fanart.index('(') + 1:fanart.rindex(')')]
		else:
			fanart = ''

		content = page.find('div', {'class': 'content'}).find('div', {'class': 'row'})
		poster = content.find('div').find('img')['src']

		title1 = content.find('h1', {'class': 'title'}).text
		title2 = ''

		serverList = page.find('ul', {'id': 'servers'})
		if serverList <> None:
			for server in serverList.find_all('li', recursive=False):
				serverName = ' '.join(server.find('label').find_all(text=True)).strip()

				streams = []
				for e in server.find('ul', {'class': 'episodes'}).find_all('a'):
					href = '%sajax/film/episode?hash_id=%s' %(self.base_url, e['data-id'])
					s = []
					ep_title = u''.join([u'Episode ', e.text.strip()])
					if ep_title in media_items:
						s = media_items[unicode(ep_title)]

					d = {'title1': unicode(title1), 'title2': unicode(title2), 'ep_title': ep_title, 'poster': poster, 'banner': fanart, 'server_name': unicode(serverName), 'href': href}
					if 'data-subtitle' in e.attrs:
						d['subtitle'] = e['data-subtitle']
					s.append(d)
					media_items[unicode(ep_title)] = s

		return media_items


	def search(self, query):
		search_url = self.base_url + 'ajax/film/search?' + urllib.urlencode({'keyword': urllib.quote_plus(query)})
		result = api.JSONKit(cache_path=self.cache_path).ObjectFromURL(search_url, cacheTime=0)

		contents = []
		if 'json' in result:
			r = result['json']
			for i in r:
				m = r[i]
				contents.append({'title1': unicode(m['title']), 'title2': unicode(m['title_o']), 'href': self.base_url + m['link'], 'duration': unicode(m['status']), 'info': unicode(m['status']), 'poster': m['image_url']})
		return {'items': contents, 'next_page': None}


	def __next_page__(self, page):
		pages = page.find('div', {'class': 'page-navigation'})
		if pages is None:
			return None
		n = pages.find('a', {'class': re.compile('.*current.*')})
		if n is None:
			return None

		next_sib = n.nextSibling
		if next_sib <> None:
			n = next_sib['href']
			return n
		return None


	def resolve_stream(self, url):
		result = api.JSONKit(cache_path=self.cache_path).ObjectFromURL(url, headers={'X-Requested-With': 'XMLHttpRequest'}, cacheTime=0)

		url = '%s?%s' %(result['grabber'], urllib.urlencode({'link': result['videoUrlHash'], 'json': 1}))
		result = api.JSONKit(cache_path=self.cache_path).ObjectFromURL(url, cacheTime=0)

		loc = None
		for c in result:
			if c['label'] == '720p':
				return c['file']
			if c['label'] == '1080p':
				return c['file']
			elif c['label'] == '360p':
				loc = c['file']
		return loc
